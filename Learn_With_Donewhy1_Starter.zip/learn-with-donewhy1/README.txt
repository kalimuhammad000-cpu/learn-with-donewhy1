LEARN WITH DONEWHY1 — STARTER WEBSITE

Files:
- index.html: complete responsive one-page website.

How to preview on Android:
1. Install/open a text editor or use Termux.
2. Put index.html in a folder.
3. In Termux, cd to that folder and run: python -m http.server 8000
4. Open http://127.0.0.1:8000 in your phone browser.

How to publish free:
- Create a GitHub account, create a public repository named learn-with-donewhy1,
  upload index.html, then enable GitHub Pages in repository Settings > Pages.
- The site will be public at the GitHub Pages address shown there.

Before publishing:
- Confirm the WhatsApp number is correct.
- Add a real instructor/team description and real course curriculum.
- Confirm the ₦20,000 offer, duration, deliverables, refund/cancellation terms.
- Have a trusted adult oversee payments and business/legal matters while the founder is under 18.
- Do not promise app-store approval; platform approval is outside your control.

Telegram:
Create a private channel and set posting permission to admins only. Enable content
protection if available. It reduces forwarding/saving but cannot stop screenshots
or recording with another device. Share invite links privately and revoke/replace
links if one is exposed.
